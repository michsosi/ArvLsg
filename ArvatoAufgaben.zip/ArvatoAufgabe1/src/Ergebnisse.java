import java.util.*;

// Die Klasse fasst alle Daten zusammen und dient nur als Zwischenschritt f�r die JSON ausgabe.
public class Ergebnisse {
public LinkedList<String> onlyInList1;
public LinkedList<String> onlyInList2;
public LinkedList<String> inBothLists;
}
