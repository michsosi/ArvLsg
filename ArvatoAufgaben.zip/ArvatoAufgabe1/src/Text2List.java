import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Text2List {
// Die Klasse stellt die Mehtoden f�r die �bertragung der Textdatei in 
// eine verkette Liste mit unterschiedlichen Eintr�gen bereit.
    
	public static void trafo(String datName, LinkedList<String> liste) {
    	// https://javabeginners.de/Ein-_und_Ausgabe/Eine_Datei_zeilenweise_auslesen.php

        File file = new File(datName);

        if (!file.canRead() || !file.isFile())
            System.exit(0);

            BufferedReader in = null;
        try {
            in = new BufferedReader(new FileReader(datName));
            String zeile = null;
            liste.clear();
            while ((zeile = in.readLine()) != null) {
               // System.out.println("Gelesene Zeile: " + zeile);
                liste.add(zeile);
                           }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (in != null)
                try {
                    in.close();
                } catch (IOException e) {
                }
        }
// Die obige Methode ist, ausser einigen kleinen Anpassungen, nicht mein Werk.   
    } 
    public static void reduktion(LinkedList<String> liste) {
    	int i = 0;
    	int j = 0;
    	// H�ufiger auftretende Begriffe werden aus der Liste gel�scht.
    	while(i< liste.size()) {
     		j=i+1;
    		while(j< liste.size()) {
    		
  //  			System.out.println(liste.get(i)+ " = "+  liste.get(j) +" ?");
        		
    			if(liste.get(i).equals(liste.get(j))) { 
  //  				System.out.println("Redudanz bei "+ j); 
    				liste.remove(j); 
    				j--;
    				}
        	 	j++;
        	 }
    	i++;
    	}
    		
    }
    
}