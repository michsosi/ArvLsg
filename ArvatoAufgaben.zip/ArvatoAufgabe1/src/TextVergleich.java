import java.util.*;
import com.google.gson.*;

public class TextVergleich {

	public static void main(String[] args) {
		
	LinkedList<String> liste1 = new LinkedList<String>();
	LinkedList<String> liste2 = new LinkedList<String>();
	
	// Beide Textdateien werden als verkettete Listen dargestellt um leichter vergleichen zu k�nnen.
	Text2List.trafo("List1.txt",liste1);
	Text2List.trafo("List2.txt",liste2);
		
	// Redundanzen werden in beiden Listen beseitigt.
	Text2List.reduktion(liste1); 
	Text2List.reduktion(liste2); 
	
	// Jedes Wort aus der ersten Liste wird in der zweiten Liste gesucht. 
	// Bei �bereinstimmung wird das Wort aus beiden Listen entfernt und an die Schnittmengenliste angeh�ngt.
	LinkedList<String> schnittmenge = new LinkedList<String>();
	
	int i=0;
	int j=0;
	while(i< liste1.size()) {
		j=0;
		while(j< liste2.size()) {
		  		
			if(liste1.get(i).equals(liste2.get(j))) { 
//				System.out.println("�bereinstimmung bei "+ j);
				schnittmenge.add(liste1.get(i));
				liste1.remove(i);
				liste2.remove(j);
				i--;
				break;
			}
			j++;
    
    	 } 
 	i++;
	}
	
	Ergebnisse ergeb = new Ergebnisse();
	ergeb.onlyInList1 = liste1;
	ergeb.onlyInList2 = liste2;
	ergeb.inBothLists = schnittmenge;
	
	GsonBuilder builder = new GsonBuilder();
    Gson gson = builder.create();
    System.out.println(gson.toJson(ergeb));
	}

}
