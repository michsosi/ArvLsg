import java.util.*;
import java.util.Random;


public class FlohMethodik {

public static void addRandomFlear(List<Flear> liste) {
	Random zufall = new Random();
	
	// Wertebereich aus der Aufgabe
	int wertung = zufall.nextInt(10); 
	wertung++;
	
	// Zu Testzwecken wird angenommen, dass ein Floh zwischen einem Cent und zehn Euro kosten kann
	int preis = zufall.nextInt(1000); 
	preis++;
	float floatpreis = (float)preis/100;
	
		
	Flear neuerFloh = new Flear("Siphonaptera",floatpreis,wertung);
	liste.add(neuerFloh);
	}

public static int getOptimalValue(float money, List<Flear> flears){
	int res = 0;
		
// Die L�nge der Liste/ Anzahl der Fl�he bestimmt die Anzahl aller M�glichkeiten, 
// die beim gew�nschten Brute-Force-/ vollst�ndige Exhaustion Ansatz untersucht werden.   		
	int n = flears.size();
	int p = (int)Math.pow(2, n);
		
// Zwei Arrays werden erstellt um f�r jede m�gliche Kombination von Fl�hen
// den (aufsummierten) Preis und die Wertung zu speichern.		
		
	int[] wertsumme = new int[p];
	float[] preissumme= new float[p];
	int aktWert = 0;
	float aktPreis = 0f;
		
		
	for(int i = 0; i<n ; i++) {
	// Jeder Durchlauf erg�nzt hier die M�glichkeiten um einen weiteren Floh, verdoppelt also den Informationsgehalt
	// der beiden Arrays.
	// Die erste H�lfte (bis zum Eintrag  "grenze") des bereits berechneten Arrays wird so belassen und repr�sentiert die 
	// M�glichkeiten ohne den neuen Floh, die zweite H�lfte (von grenze bis 2*grenze-1) ber�cksichtigt die Hinzunahme. 			

		aktWert=flears.get(i).getRating();
		aktPreis=flears.get(i).getPrice();
		int grenze = (int)Math.pow(2, i);
			
		for(int j = 0; j <= grenze -1 ;j++ ) {
			wertsumme[grenze+j] = wertsumme[j]+aktWert;
			preissumme[grenze+j] = preissumme[j]+aktPreis;
		}
			
	}
		
	for(int i=0 ; i < p ; i++) {
	// Das Preis-Array wird druchlaufen und ber�cksichtigt nur M�glichkeiten f�r 
	// das Maximum, die die Nebenbedingung an den Gesamtpreis erf�llen. 
			
		if(preissumme[i]<=money) {
			if(wertsumme[i] > res)  res = wertsumme[i];
		}
	}
	
		return res;
		// Ein Branch&Bound-Ansatz w�re mathematisch eleganter gewesen.
		// Branch&Bound ist f�r mich aber auf den ersten Blick keine Brute-Force Methode. �\_(-.-)_/�
}
	
}
