import java.util.*;

public class FlohRucksack {

	public static void main(String[] args) {
		LinkedList<Flear> flears = new LinkedList<Flear>();
		
// Testfl�he werden generiert und der Flohliste angeh�ngt.		
		for(int i = 0; i<5; i++) {
		FlohMethodik.addRandomFlear(flears);
		}
	
		System.out.println(FlohMethodik.getOptimalValue(10, flears));
		
	}

}
 